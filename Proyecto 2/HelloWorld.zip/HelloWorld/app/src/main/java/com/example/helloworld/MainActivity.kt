package com.example.helloworld

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

//MainActivity extends from AppCompatActivity giving it more functionality.
class MainActivity : AppCompatActivity() {
    //onCreate is a lifecycle method that runs only once at the start of the app.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    //Override all lifecycle methods to learn about them!
    

}